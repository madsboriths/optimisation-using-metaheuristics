

Default run command: "julia s194624.jl <instance_location> <solution_location>"

By default an alpha value of 0.8 is used. 
You can also specify this with an extra argument: 
    "julia s194624.jl <instance_location> <solution_location> <alpha>"
for example:
    "julia s194624.jl Instances/jeu_100_25_3_1.txt sols/jeu_100_25_3_1.sol 60 1